package edu.truman.cs260.shan.Shape;
import java.awt.*;

public interface MovableShape {
    public void move();
    public void draw(Graphics2D g2);
}
